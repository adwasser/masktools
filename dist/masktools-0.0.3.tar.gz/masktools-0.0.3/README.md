masktools
=========

Utilities for designing DEIMOS slitmasks

Contact: <adwasser@ucsc.edu>
Website: <https://github.com/adwasser/masktools>

masktools.superskims
--------------------

This package is for creating distributions of SKiMS (Stellar Kinematics with Multiple Slits) 
which optimally sample the integrated stellar light of a galaxy.

Authors: Nicola Pastorello and Asher Wasserman
