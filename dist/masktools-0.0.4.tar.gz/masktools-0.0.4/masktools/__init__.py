from __future__ import (absolute_import, division,
                        print_function, unicode_literals)

# set __version__
from .version import __version__

# set packages
import masktools.superskims
